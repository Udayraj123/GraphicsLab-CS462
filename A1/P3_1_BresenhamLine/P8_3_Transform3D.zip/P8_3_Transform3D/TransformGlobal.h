extern SHAPE_DATA gShpData;
extern const char *szShapeType[];
extern const char *szRotateType[];

