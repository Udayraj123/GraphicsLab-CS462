extern DRAWING_DATA gDrawData;
extern SHAPE3D shape;
extern double V[4][3];
extern int MAX_SURFACES;
extern int MAX_SURFACE_EDGES;
extern COLOR clrEdge;
