bool isPointWithinPolygon(const POINT2D &pt, POINT2D vert[],
                          int count);
bool isPtOnPolygonEdge(const POINT2D &pt, POINT2D vert[], 
                       int count);
void drawPixelAt(double a, double b, COLOR clr);

