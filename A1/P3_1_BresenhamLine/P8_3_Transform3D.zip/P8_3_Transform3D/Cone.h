void setConeData(double coneBaseRadius, double coneHeight);
